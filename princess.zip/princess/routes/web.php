<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\homeController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [homeController::class, 'index'])->name('home');

 Route::view('payment', 'payment-page');

Route::get('/rooms', [homeController::class, 'rooms'])->name('rooms');


Route::get('/room/{id}', [homeController::class, 'room'])->name('room');


Route::post('/booking', [homeController::class, 'booking'])->name('booking');


Route::post('/Makebooking', [homeController::class, 'MakeBooking'])->name('Makebooking');

//Route::view('/payment',  'payment-page');



