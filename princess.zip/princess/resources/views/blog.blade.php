<!DOCTYPE html>
<html class="no-js" lang="en">

<!-- Mirrored from www.weibergmedia.com/demos/ct/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 May 2022 21:41:38 GMT -->
<head>
<meta charset="utf-8">
<title>Clifton Hotel - One-Page Parallax HTML5 Travel Booking Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="weibergmedia">
<meta name="Description" content="Clifton Hotel - One-Page Parallax HTML5 Travel Booking Template" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://fonts.googleapis.com/css?family=Oswald:400,600,700" rel="stylesheet" type="text/css" />
<link href="http://fonts.googleapis.com/css?family=Lora:400,400italic,600" rel="stylesheet" type="text/css" />
<script src="js/modernizr.custom.js" type="text/javascript"></script>
</head>
<body class="blog">
<!-- start half-page intro -->
<section class="bg-image-4 with-bg parallax parallax1 section header-section">
  <div class="overlay">
    <div class="parent">
      <div class="child">
        <h1>Clifton Blog <span class="italic">&amp;</span> Journal</h1>
        <p class="large">Say Something!</p>
      </div>
    </div>
  </div>
</section>
<!-- end half-page intro --> 
<!-- start header -->
<header class="clearfix">
  <div id="logo"> <a href="index.html">Clifton</a> </div>
  <div class="tagline"><span>Hotel &amp; Resort</span></div>
  <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
  <nav>
    <ul id="nav">
      <li><a href="index.html#ancor1">Home</a> </li>
      <li><a href="index.html#ancor2">Rooms</a> </li>
      <li><a href="index.html#ancor3">Reservation</a> </li>
      <li><a href="index.html#ancor4">About</a> </li>
      <li><a href="index.html#ancor5">Deals</a> </li>
      <li><a href="index.html#ancor6">Contact</a> </li>
      <li class="active"><a href="blog.html">Blog</a> </li>
    </ul>
  </nav>
</header>
<!-- end header --> 
<!-- start main content -->
<section class="section">
  <div class="container clearfix extra-padding-top">
    <div class="col-md-9 col-sm-7">
      <div class="row">
        <div id="container" class="clearfix">


        @foreach( $rooms as $room)
          <div class="element home  col-md-6">
            <div class="margin-wrapper"> <img alt="" src="images/blog01.jpg" />
              <div class="more-info">
               
                <h3>{{ $room->name}}</h3>
               <ul>
              <li>Occupancy: {{ $room->occupancy}}</li>
              <li>Sitting Room: {{ $room->sittingroom	}}</li>
              <li>Jaccuzi: {{ $room->jaccuzi}}</li>

              <p class="button" style="background-color: green;" title="">{{ $room->price}}</p>

               </ul>
                <a href="{{ route('room', $room->id)}}" class="button" title="">Book Room</a> </div>
            </div>
          </div>

          @endforeach
       

          
        
         
        
         
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-5 widgets">
      <input name="name" type="text" id="name" value="Search ..." class="search-widget" />
      <aside>
        <h5>About</h5>
        <p>We are regarded as industry leaders in stunning website solutions, focused on delivering unsurpassed designs.</p>
      </aside>
      <aside>
        <h5>Recent Posts</h5>
        <ul class="unordered-list clearfix">
          <li><a href="#" title="">First Impressions Last</a></li>
          <li><a href="#" title="">Features Soundcloud Widgets of Cranes</a></li>
          <li><a href="#" title="">This Is a Rather Cool Video!</a></li>
        </ul>
      </aside>
      <aside>
        <h5>Recent Comments</h5>
        <ul class="unordered-list clearfix">
          <li><span class="small"><a href="#" title="">John Doe</a></span> on <br />
            <a href="#" title="">First Impressions Last</a></li>
          <li><span class="small"><a href="#" title="">Mark Anthony</a></span> on <br />
            <a href="#" title="">www.clifton.com</a></li>
        </ul>
      </aside>
      <aside>
        <h5>Categories</h5>
        <ul class="unordered-list clearfix">
          <li><a href="#" title="">Camera</a> <span class="small">(2)</span></li>
          <li><a href="#" title="">Lifestyle</a> <span class="small">(18)</span></li>
          <li><a href="#" title="">Food</a> <span class="small">(1)</span></li>
          <li><a href="#" title="">People</a> <span class="small">(4)</span></li>
        </ul>
      </aside>
    </div>
  </div>
  <div class="container clearfix custom-pagination">
    <div class="col-lg-12">
      <div class="left inactive"><a href="#" title="">
        <div class="arrow-left"></div>
        <div class="alignleft">
          <h5>Newer Posts</h5>
        </div>
        </a></div>
      <div class="right"><a href="#" title="">
        <div class="arrow-right"></div>
        <div class="alignright">
          <h5>Older Posts</h5>
        </div>
        </a> </div>
    </div>
  </div>
</section>
<!-- end main content --> 
<!-- start footer -->
<footer>
  <div class="container clearfix">
    <div class="col-lg-12"> <span class="alignleft small">© 2017, Clifton Hotel. All Rights Reserved.</span> <span class="alignright small">Made with <i class="fa fa-heart"></i> by <a href="http://www.weibergmedia.com/" data-title="Premium HTML5 Website Templates">weibergmedia</a>. </span> </div>
  </div>
</footer>
<!-- end footer --> 
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 
<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/jquery.touchSwipe.min.js" type="text/javascript"></script> 
<script src="js/jquery.isotope2.min.js" type="text/javascript"></script> 
<script src="js/packery-mode.pkgd.min.js" type="text/javascript"></script> 
<script src="js/jquery.isotope.load.js" type="text/javascript"></script> 
<script src="js/jquery.nav.js" type="text/javascript"></script> 
<script src="js/responsive-nav.js" type="text/javascript"></script> 
<script src="js/jquery.sticky.js" type="text/javascript"></script> 
<script src="js/jquery.form.js" type="text/javascript"></script> 
<script src="js/starter.js" type="text/javascript"></script> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<script src="js/ajax.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-datepicker.min.js"></script> 
<script src="js/jquery.fitvids.js" type="text/javascript"></script> 
<script src="js/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script> 
<script src="js/googlemaps.js" type="text/javascript"></script> 
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</body>

<!-- Mirrored from www.weibergmedia.com/demos/ct/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 May 2022 21:41:38 GMT -->
</html>
