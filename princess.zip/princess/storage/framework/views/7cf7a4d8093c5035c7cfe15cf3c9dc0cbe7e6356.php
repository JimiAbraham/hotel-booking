<!DOCTYPE html>
<html class="no-js" lang="en">

<!-- Mirrored from www.weibergmedia.com/demos/ct/post.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 May 2022 21:41:44 GMT -->
<head>
<meta charset="utf-8">
<title>Clifton Hotel - One-Page Parallax HTML5 Travel Booking Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="weibergmedia">
<meta name="Description" content="Clifton Hotel - One-Page Parallax HTML5 Travel Booking Template" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://fonts.googleapis.com/css?family=Oswald:400,600,700" rel="stylesheet" type="text/css" />
<link href="http://fonts.googleapis.com/css?family=Lora:400,400italic,600" rel="stylesheet" type="text/css" />
<script src="js/modernizr.custom.js" type="text/javascript"></script>
</head>
<body class="blog">
<!-- start header -->
<header class="clearfix">
  <div id="logo"> <a href="index.html">Clifton</a> </div>
  <div class="tagline"><span>Hotel &amp; Resort</span></div>
  <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
  <nav>
    <ul id="nav">
      <li><a href="index.html#ancor1">Home</a> </li>
      <li><a href="index.html#ancor2">Rooms</a> </li>
      <li><a href="index.html#ancor3">Reservation</a> </li>
      <li><a href="index.html#ancor4">About</a> </li>
      <li><a href="index.html#ancor5">Deals</a> </li>
      <li><a href="index.html#ancor6">Contact</a> </li>
      <li class="active"><a href="blog.html">Blog</a> </li>
    </ul>
  </nav>
</header>
<!-- end header --> 
<!-- start main content -->

<section class="section white-bg">
  <div class="container clearfix extra-padding-top">
    



    <div class="col-md-6">
      <h4>Booking Details</h4>
      <div class="comment clearfix">
        <div class="commenter-avatar">
          <div class="round"><img alt="" src="images/about16.jpg" /></div>
        </div>
        <div class="comment-content">
          <h5>You want to book <?php echo e($RoomName); ?> Room</h5>
          <!-- <p><span class="small">January 8, 2016</span> <span class="padding"><a href="#">Reply</a></span></p> -->
          <p>It has the following features</p>
          <ul>

          <li>It can accommodate 2 Persons</li>
          <li>It has Jaccuzi</li>
          <li>It has wifi</li>
          <li>Price is <?php echo e($RoomPrice); ?> per night</li>
          </ul>
          <br>
          <br>
          <h5>Your Total Bill is:<?php echo e($RoomAmount); ?> </h5>
          <!-- <p><span class="small">January 8, 2016</span> <span class="padding"><a href="#">Reply</a></span></p> -->
          <p>Your Booking details</p>
          <ul>

          <li>ChecIn date: <?php echo e($checkin); ?></li>
          <li>checkout date: <?php echo e($checkout); ?></li>
          <li>You intend to stay for <?php echo e($days); ?> days</li>
          <li>Occupants: <?php echo e($Adultnum); ?> adults and <?php echo e($Childnum); ?> children </li>
          </ul>
        </div>

        
      </div>
      <div class="break"></div>
    </div>
    <div class="col-md-6">
      <h4>Submit Your details</h4>
      <div id="contact">
        <form method="post" action="<?php echo e(route('Makebooking')); ?>" autocomplete="off">
          <?php echo csrf_field(); ?>
          <fieldset>
            <label>Full Name</label>
            <input name="name" type="text" id="name" />
            <label>Email</label>
            <input name="email" type="text" id="email" />
            <label>Phone Number</label>
            <input name="address" type="text" id="email" />
            <label>Address</label>
            <input name="phone" type="text" id="" />
            <label>Say Something!</label>
            <textarea name="comments" id="comments"></textarea>

            <input type="hidden" name="roomId" value="<?php echo e($Room); ?>">
          <input type="hidden" name="checkin" value="<?php echo e($checkin); ?>">
          <input type="hidden" name="checkout" value="<?php echo e($checkout); ?>">

          <input type="hidden" name="adult" value="<?php echo e($Adultnum); ?>">
          <input type="hidden" name="children" value="<?php echo e($Childnum); ?>">
          <input type="hidden" name="amount" value="<?php echo e($RoomAmount); ?>">

            <div class="button full-width">
              <input type="submit" class="submit"  value="Make Bookings" />
            </div>
            <span id="message"></span>
          </fieldset>

        
          
        </form>
      </div>
    </div>
  </div>
</section>

<!-- end main content --> 
<!-- start footer -->
<footer>
  <div class="container clearfix">
    <div class="col-lg-12"> <span class="alignleft small">© 2017, Clifton Hotel. All Rights Reserved.</span> <span class="alignright small">Made with <i class="fa fa-heart"></i> by <a href="http://www.weibergmedia.com/" data-title="Premium HTML5 Website Templates">weibergmedia</a>. </span> </div>
  </div>
</footer>
<!-- end footer --> 
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 
<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/jquery.touchSwipe.min.js" type="text/javascript"></script> 
<script src="js/jquery.isotope2.min.js" type="text/javascript"></script> 
<script src="js/packery-mode.pkgd.min.js" type="text/javascript"></script> 
<script src="js/jquery.isotope.load.js" type="text/javascript"></script> 
<script src="js/jquery.nav.js" type="text/javascript"></script> 
<script src="js/responsive-nav.js" type="text/javascript"></script> 
<script src="js/jquery.sticky.js" type="text/javascript"></script> 
<script src="js/jquery.form.js" type="text/javascript"></script> 
<script src="js/starter.js" type="text/javascript"></script> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<script src="js/ajax.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-datepicker.min.js"></script> 
<script src="js/jquery.fitvids.js" type="text/javascript"></script> 
<script src="js/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script> 
<script src="js/googlemaps.js" type="text/javascript"></script> 
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</body>

<!-- Mirrored from www.weibergmedia.com/demos/ct/post.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 May 2022 21:41:47 GMT -->
</html><?php /**PATH C:\Users\USER\Desktop\server\htdocs\princess\resources\views/makeBooking.blade.php ENDPATH**/ ?>