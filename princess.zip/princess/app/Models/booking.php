<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'email',
        'room_id',
        'address',
        'phone',
        'comment',
        'amount',
        'children',
        'adult',
        'checkout',
        'checkin',
        
    ];

    public function room()
    {
        return $this->belongsTo(room::class);
    }
}
