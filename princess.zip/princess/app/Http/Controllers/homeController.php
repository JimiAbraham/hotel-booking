<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\room;
use Illuminate\Support\Carbon;
use App\Models\booking;

class homeController extends Controller
{
    public function index()
    {

        $homeRoom  = room::inRandomOrder()->limit(5)->get();

        return view('index', compact('homeRoom'));
    }



    public function rooms()
    {
        $rooms = room::all();

        return view('blog', compact('rooms'));
    }


    public function room(REQUEST $request, $id)
    {
        //  dd($id);
        // dd('testing');

     $RoomDetails = room::find($id);

     return view('bookingPage', compact('RoomDetails'));

    }


    
    public function booking(REQUEST $request)
    {
         //dd($request->all());

      $validate =    $request->validate([
            'checkin' => 'required|date',
            'checkout' => 'required|date|after:checkin',
        ]);

    
     
        $availability = booking::where('room_id', $request->room)
                                ->whereDate('checkin','<=',$request->checkin)
                                ->whereDate('checkout','>=',$request->checkin)
                                ->exists();

        // dd($availability);

        if ($availability)
        {

            $alternative = room::all();

            return view('NewbookingPage', compact('alternative'));

        }

        $roomDetails = room::where('id', [$request->room])->first();

        // dd( $roomDetails->price);

        $CheckOutDate = Carbon::parse($request->checkout);

            $CheckInDate = Carbon::parse($request->checkin);
            $DaysOfStay = $CheckOutDate->diffInDays($CheckInDate);

            //dd($DaysOfStay);


            $Amount =  $roomDetails->price * $DaysOfStay;

            //dd($Amount);

        $Room = session('RoomData', $request->room);
        $checkin = session('RoomData', $request->checkin);
        $checkout = session('RoomData', $request->checkout);
        $Adultnum = session('RoomData', $request->adults);
        $Childnum = session('RoomData', $request->children);
        $RoomName = session('RoomData', $roomDetails->name);
        $RoomPrice = session('RoomData', $roomDetails->price);
        $days = session('RoomData', $DaysOfStay);
        $RoomAmount = session('RoomData',$Amount );
      



       // dd($Room);


        return view('makeBooking', 
compact(['Room','checkin','checkout','Adultnum','Childnum','RoomName','RoomPrice', 'days', 'RoomAmount' ]));

    //echo "save room details in a session and move data to payment and sign up page";
      

    }


    public function MakeBooking( Request $request)

    {

        //dd( $request->all());


       $booked = booking::create([

        'checkin' => $request->checkin,
        'checkout' => $request->checkout,
        'adult'=> $request->adult,
        'children' => $request->children,
        'email' => $request->email,
        'room_id' => $request->roomId,
        'amount' => $request->amount,
        'name' => $request->name,
        'address' => $request->address,
        'phone' => $request->phone,
        'comment' => $request->comments,
       
       ]);

       $amount = $request->amount;

       //dd($amount);
       if ($booked){
        return view('payment-page', compact(['amount']));
  
            }

    return back();

  
}
}