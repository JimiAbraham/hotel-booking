<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\room;

class rooms extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        room::create([
            'name' => 'Presidential Suites',
            'sittingroom' => '1',
            'occupancy' => '1 Person',
            'size' => '60-80sqm',
            'jaccuzi' => 'Available',
            'wifi' => 'Available',
            'price' => '40000.00',
            'ImageUrl' => 'https://media.cntraveler.com/photos/53da5ab46dec627b149e50d3/master/w_1024,h_768,c_limit/provocateur-suite-hard-rock-hotel-las-vegas.jpg',
           
        ]);

        room::create([
            'name' => 'Ambassador Suites',
            'sittingroom' => '1',
            'occupancy' => '2 Persons',
            'size' => '600mm by 240sqm',
            'jaccuzi' => 'Not Avaialable',
            'wifi' => 'Available',
            'price' => '33350.00',
            'ImageUrl' => 'https://i.insider.com/5db9a47d045a31328a5b6fde?width=600&format=jpeg&auto=webp',

           
        ]);


        room::create([
            'name' => 'Diplomatic Suite',
            'sittingroom' => '1',
            'occupancy' => '3 Person',
            'size' => '1150mm by 450m',
            'jaccuzi' => 'Not Avaialable',
            'wifi' => 'Available',
            'price' => '3000.00',
            'ImageUrl' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR22vyCEvPhvAGMgmGYCUO7al45E_BlHKElPRrS-_D7ITkce0YncH_wEriFyI1m_NBmz8c&usqp=CAU',
      
        ]);


        room::create([
            'name' => 'Ministerial Suite',
            'sittingroom' => 'Nil',
            'occupancy' => '2 Persons',
            'size' => '650mm by 350m',
            'jaccuzi' => 'Avaialable',
            'wifi' => 'Available',
            'price' => '73500.00',
            'ImageUrl' => 'https://thewhistler.ng/wp-content/uploads/2021/02/oyo-15970-gb-oceania-1.jpg',
      
        ]);


        room::create([
            'name' => 'Freelancer Suite',
            'sittingroom' => 'Nil',
            'occupancy' => '1 Person',
            'size' => '150mm by 250m',
            'jaccuzi' => 'Avaialable',
            'wifi' => 'Available',
            'price' => '20000.00',
            'ImageUrl' => 'https://www.planetware.com/wpimages/2020/01/best-underwater-hotels-intercontinental-shanghai-wonderland.jpg',
      
        ]);
    }
}
